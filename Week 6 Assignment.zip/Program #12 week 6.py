def print_payroll_report(filename):
    # Print the header of the report
    print("Payroll Report")
    print("{:<15} {:<12} {:<10}".format("Employee", "Hours Worked", "Wages Paid"))
    print("---------------------------------------")

    try:
        with open(filename, 'r') as file:
            for line in file:
                # Split the line into employee information
                employee_info = line.split()

                # Extract the relevant information
                last_name = employee_info[0]
                hourly_wage = float(employee_info[1])
                hours_worked = float(employee_info[2])

                # Calculate the wages paid for the period
                wages_paid = hourly_wage * hours_worked

                # Print the employee information and wages paid
                print("{:<15} {:<12.2f} ${:<10.2f}".format(last_name, hours_worked, wages_paid))
    except FileNotFoundError:
        print("The file does not exist.")


# Prompt the user for input
filename = input("Enter the filename: ")

# Print the payroll report
print_payroll_report(filename)
