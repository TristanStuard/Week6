def copy_file(source_file, destination_file):
    try:
        with open(source_file, 'r') as file1:
            data = file1.read()
            with open(destination_file, 'w') as file2:
                file2.write(data)
        print("File copied successfully!")
    except FileNotFoundError:
        print("One or both of the files does not exist.")


# Prompt the user for input
source_file = input("Enter the name of the source file: ")
destination_file = input("Enter the name of the destination file: ")

# Copy the contents of the source file to the destination file
copy_file(source_file, destination_file)
