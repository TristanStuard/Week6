def caesar_decipher(encrypted_text, distance):
    plaintext = ""
    for char in encrypted_text:
        if char.isprintable():
            if char.isalpha():
                # Determine the case of the character
                if char.isupper():
                    base = ord('A')
                else:
                    base = ord('a')

                # Apply the Caesar cipher in reverse with the given distance
                decrypted_char = chr((ord(char) - base - distance) % 26 + base)
                plaintext += decrypted_char
            else:
                # Non-alphabetic characters remain unchanged
                plaintext += char
        else:
            # Non-printable characters remain unchanged
            plaintext += char

    return plaintext


# Prompt the user for input
encrypted_text = input("Enter the encrypted text: ")
distance = int(input("Enter the distance value: "))

# Decrypt the encrypted text using Caesar cipher
plaintext = caesar_decipher(encrypted_text, distance)

# Print the plaintext
print("Plaintext:", plaintext)
