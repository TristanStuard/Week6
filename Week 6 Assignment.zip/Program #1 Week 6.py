def caesar_cipher(plaintext, distance):
    encrypted_text = ""
    for char in plaintext:
        if char.isprintable():
            if char.isalpha():
                # Determine the case of the character
                if char.isupper():
                    base = ord('A')
                else:
                    base = ord('a')

                # Apply the Caesar cipher with the given distance
                encrypted_char = chr((ord(char) - base + distance) % 26 + base)
                encrypted_text += encrypted_char
            else:
                # Non-alphabetic characters remain unchanged
                encrypted_text += char
        else:
            # Non-printable characters remain unchanged
            encrypted_text += char

    return encrypted_text


# Prompt the user for input
plaintext = input("Enter the plaintext: ")
distance = int(input("Enter the distance value: "))

# Encrypt the plaintext using Caesar cipher
encrypted_text = caesar_cipher(plaintext, distance)

# Print the encrypted text
print("Encrypted text:", encrypted_text)
